import numpy as np
import requests
from ultralytics import YOLO
from PIL import Image
from io import BytesIO
from flask import Flask, request, jsonify

app = Flask(__name__)

# 내모델이 저장된 장소
model = YOLO('./best.pt')

# 클래스 이름 설정
all_class_names = ['casual_look', 'classic_look', 'minimal_look', 'chic_look', 'sporty_look', 'street_look', 'person']

# 이미지 URL을 처리하고 예측 수행
def predict_image_from_url(image_url):
    try:
        # 이미지 다운로드
        response = requests.get(image_url)
        img = Image.open(BytesIO(response.content))

        # YOLO 모델로 예측 수행
        result = model.predict(img)
        class_probs = {class_name: 0 for class_name in all_class_names}

        # 감지된 객체 처리
        if result[0].boxes is not None and len(result[0].boxes) > 0:
            for detection in result[0].boxes:
                conf = detection.conf.item()  # confidence score
                class_idx = int(detection.cls.item())  # class index
                class_name = all_class_names[class_idx]
                class_probs[class_name] = max(class_probs[class_name], conf)
            return class_probs
        else:
            return None
    except Exception as e:
        print(f"Error processing image: {e}")
        return None

# 이미지에서 6D 벡터를 얻는 함수 (URL 사용)
def get_6d_vector(image_urls):
    vectors = []
    for image_url in image_urls:
        class_probs = predict_image_from_url(image_url)
        if class_probs is not None:
            if class_probs['person'] > 0:
                filtered_probs = [class_probs[cls] for cls in all_class_names if cls != 'person']
                vectors.append(filtered_probs)
    if len(vectors) > 0:
        return np.mean(vectors, axis=0)  # 각 열의 평균을 내서 6D 벡터 생성
    else:
        return None

# Flask 라우트 설정
@app.route('/process_images', methods=['POST'])
def process_images():
    try:
        # 클라이언트로부터 이미지 URL 리스트 받기
        data = request.json
        if 'image_urls' not in data or not isinstance(data['image_urls'], list):
            return jsonify({'error': 'Invalid input, image_urls must be provided as a list'}), 400
        
        image_urls = data['image_urls']
        
        # 이미지 URL에서 6D 벡터 생성
        vector = get_6d_vector(image_urls)
        if vector is None:
            return jsonify({'error': 'No valid images or person not detected'}), 400

        # 클러스터 예측 서버로 POST 요청
        external_url = 'http://j11e104a.p.ssafy.io:5000/predict'
        response = requests.post(external_url, json={'point': vector.tolist()})
        
        # 외부 서버에서 받은 응답 반환
        if response.status_code == 200:
            return jsonify(response.json()), 200
        else:
            return jsonify({'error': 'Failed to get valid response from external server'}), response.status_code

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)